DROP DOMAIN vin_type;

DROP SEQUENCE salony_salony_id_seq;
DROP SEQUENCE paliwo_paliwo_id_seq;
DROP SEQUENCE klienci_klienci_id_seq;
DROP SEQUENCE marki_marki_id_seq;
DROP SEQUENCE modele_modele_id_seq;
DROP SEQUENCE samochody_samochody_id_seq;
DROP SEQUENCE sprzedaze_sprzedaze_id_seq;
DROP SEQUENCE pracownicy_pracownicy_id_seq;