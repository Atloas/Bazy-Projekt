DELETE FROM sprzedaze;
DELETE FROM samochody;
DELETE FROM modele;
DELETE FROM marki;
DELETE FROM paliwo;
DELETE FROM klienci;
DELETE FROM pracownicy;
DELETE FROM salony;