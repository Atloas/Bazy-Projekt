DROP VIEW sprzedaneSamochody;
DROP VIEW nieSprzedaneSamochody;
DROP VIEW klienciBezZakupu;